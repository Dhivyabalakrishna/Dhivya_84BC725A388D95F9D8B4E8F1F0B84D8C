#ifndef __mbstate_t_defined
#define __mbstate_t_defined 1

#include <bits/types/__mbstate_t.h>

typedef __mbstate_t mbstate_t;

#endif
